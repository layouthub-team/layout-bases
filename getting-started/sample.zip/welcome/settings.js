[   
     {
         tab_name:"General",
         settings: [
             {
                 type : "text",
                 name:"title",
                 label: "Block title",
                 value: "Welcom to LayoutHub development team"
             },
             {
                 type: 'image',
                 name: 'logo',
                 label: 'Logo',
                 value: '%URL%assets/logo.png'
             },
             {
                 type: "textarea",
                 label: "Description text",
                 name: "description",
                 value: "LayoutHub is the best page builder for Shopify"
             }
         ]
     }
]