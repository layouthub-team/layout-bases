[
    {
        name: 'cta',
        label: 'Call to action',
        type: 'link',
        value: {
	        href: '#',
	        text: 'Call to action',
	        'data-ga-action': 'tracking'
        },
        options: {
	        source: '%URL%assets/fonts/fa-solid.css',
	        ext_class: 'fa'
        }
    },
    {
        name: 'text',
        label: 'Text',
        type: 'text'
    }
]