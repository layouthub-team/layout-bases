[
    {
        name: 'images',
        label: 'Images Gallery',
        type: 'picker',
        value: [{
        	thumbnail: '%URL%thumbnail.jpg',
        	value: '%URL%thumbnail.jpg',
        	name: 'Default'
        }],
        options: {
	        multiple: false,
	        layout: 'list',
	        type: 'images'
        }
    }
]